/*
Copyright 2012-2014 Kasper Skårhøj, SKAARHOJ K/S, kasper@skaarhoj.com

This file is part of the Blackmagic Design ATEM Client library for Arduino

The ATEM library is free software: you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by the 
Free Software Foundation, either version 3 of the License, or (at your 
option) any later version.

The ATEM library is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE. 
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along 
with the ATEM library. If not, see http://www.gnu.org/licenses/.


IMPORTANT: If you want to use this library in your own projects and/or products,
please play a fair game and heed the license rules! See our web page for a Q&A so
you can keep a clear conscience: http://skaarhoj.com/about/licenses/


*/



#include "Arduino.h"
#include "ATEMuniFix.h"


/**
 * Constructor (using arguments is deprecated! Use begin() instead)
 */
ATEMuni::ATEMuni(){
	for(uint8_t i = 0; i < 21; i++) {
		atemCameraControlGain[i] = 512;
		atemCameraControlWhiteBalance[i] = 3200;

		atemCameraControlLumMix[i] = 2048;
		atemCameraControlShutter[i] = 10000;
		
		atemCameraControlContrast[i] = 2048;
		atemCameraControlSaturation[i] = 2048;
		
		atemCameraControlGainR[i] = 2048;		
		atemCameraControlGainG[i] = 2048;
		atemCameraControlGainB[i] = 2048;
		atemCameraControlGainY[i] = 2048;
	}
}



uint8_t ATEMuni::getTallyFlags(uint16_t videoSource)  {
  for (uint8_t a = 0; a < getTallyBySourceSources(); a++)  {
    if (getTallyBySourceVideoSource(a) == videoSource)  {
    	return getTallyBySourceTallyFlags(a);
    }
  }
  return 0;
}


void ATEMuni::setCameraControlVideomode(uint8_t input, uint8_t fps, uint8_t resolution, uint8_t interlaced, uint8_t mrate) {
		_prepareCommandPacket(PSTR("CCmd"), 24);

		_packetBuffer[12+_cBBO+4+4+0] = input;

		_packetBuffer[12+_cBBO+4+4+1] = 1;
		_packetBuffer[12+_cBBO+4+4+2] = 0;

		_packetBuffer[12+_cBBO+4+4+4] = 0x01; // Data type: int8

		// Reduncancy: Support for ATEM Switchers & ATEM Proxy
		_packetBuffer[12+_cBBO+4+4+7] = 0x05;
		_packetBuffer[12+_cBBO+4+4+9] = 0x05;

		_packetBuffer[12+_cBBO+4+4+16] = fps;
		_packetBuffer[12+_cBBO+4+4+17] = mrate; // Regular M-rate
		_packetBuffer[12+_cBBO+4+4+18] = resolution;
		_packetBuffer[12+_cBBO+4+4+19] = interlaced;
		_packetBuffer[12+_cBBO+4+4+20] = 0x00; // YUV

		_finishCommandPacket();
}


	void ATEMuni::setCameraControlLift(uint8_t input, int liftR, int liftG, int liftB, int liftY) {
  		_prepareCommandPacket(PSTR("CCmd"),24);

			// Preset values:
		_packetBuffer[12+_cBBO+4+4+1] = 8;
		_packetBuffer[12+_cBBO+4+4+2] = 0;

		_packetBuffer[12+_cBBO+4+4+4] = 0x80;
		_packetBuffer[12+_cBBO+4+4+9] = 0x04;

		_packetBuffer[12+_cBBO+4+4+0] = input;

		_packetBuffer[12+_cBBO+4+4+16] = highByte(liftR);
		_packetBuffer[12+_cBBO+4+4+17] = lowByte(liftR);
		_packetBuffer[12+_cBBO+4+4+18] = highByte(liftG);
		_packetBuffer[12+_cBBO+4+4+19] = lowByte(liftG);
		_packetBuffer[12+_cBBO+4+4+20] = highByte(liftB);
		_packetBuffer[12+_cBBO+4+4+21] = lowByte(liftB);
		_packetBuffer[12+_cBBO+4+4+22] = highByte(liftY);
		_packetBuffer[12+_cBBO+4+4+23] = lowByte(liftY);

   		_finishCommandPacket();
	}

	void ATEMuni::setCameraControlGamma(uint8_t input, int gammaR, int gammaG, int gammaB, int gammaY) {
  		_prepareCommandPacket(PSTR("CCmd"),24);

			// Preset values:
		_packetBuffer[12+_cBBO+4+4+1] = 8;
		_packetBuffer[12+_cBBO+4+4+2] = 1;

		_packetBuffer[12+_cBBO+4+4+4] = 0x80;
		_packetBuffer[12+_cBBO+4+4+9] = 0x04;

		_packetBuffer[12+_cBBO+4+4+0] = input;

		_packetBuffer[12+_cBBO+4+4+16] = highByte(gammaR);
		_packetBuffer[12+_cBBO+4+4+17] = lowByte(gammaR);
		_packetBuffer[12+_cBBO+4+4+18] = highByte(gammaG);
		_packetBuffer[12+_cBBO+4+4+19] = lowByte(gammaG);
		_packetBuffer[12+_cBBO+4+4+20] = highByte(gammaB);
		_packetBuffer[12+_cBBO+4+4+21] = lowByte(gammaB);
		_packetBuffer[12+_cBBO+4+4+22] = highByte(gammaY);
		_packetBuffer[12+_cBBO+4+4+23] = lowByte(gammaY);


		_finishCommandPacket();
	}

	void ATEMuni::setCameraControlGain(uint8_t input, int gainR, int gainG, int gainB, int gainY) {
  		_prepareCommandPacket(PSTR("CCmd"),24);

			// Preset values:
		_packetBuffer[12+_cBBO+4+4+1] = 8;
		_packetBuffer[12+_cBBO+4+4+2] = 2;

		_packetBuffer[12+_cBBO+4+4+4] = 0x80;
		_packetBuffer[12+_cBBO+4+4+9] = 0x04;

		_packetBuffer[12+_cBBO+4+4+0] = input;

		_packetBuffer[12+_cBBO+4+4+16] = highByte(gainR);
		_packetBuffer[12+_cBBO+4+4+17] = lowByte(gainR);
		_packetBuffer[12+_cBBO+4+4+18] = highByte(gainG);
		_packetBuffer[12+_cBBO+4+4+19] = lowByte(gainG);
		_packetBuffer[12+_cBBO+4+4+20] = highByte(gainB);
		_packetBuffer[12+_cBBO+4+4+21] = lowByte(gainB);
		_packetBuffer[12+_cBBO+4+4+22] = highByte(gainY);
		_packetBuffer[12+_cBBO+4+4+23] = lowByte(gainY);

		_finishCommandPacket();
	}
	
	

	void ATEMuni::setCameraControlHueSaturation(uint8_t input, int hue, int saturation) {
  		_prepareCommandPacket(PSTR("CCmd"),24);

			// Preset values:
		_packetBuffer[12+_cBBO+4+4+1] = 8;
		_packetBuffer[12+_cBBO+4+4+2] = 6;

		_packetBuffer[12+_cBBO+4+4+4] = 0x80;
		_packetBuffer[12+_cBBO+4+4+9] = 0x02;

		_packetBuffer[12+_cBBO+4+4+0] = input;

		_packetBuffer[12+_cBBO+4+4+16] = highByte(hue);
		_packetBuffer[12+_cBBO+4+4+17] = lowByte(hue);

		_packetBuffer[12+_cBBO+4+4+18] = highByte(saturation);
		_packetBuffer[12+_cBBO+4+4+19] = lowByte(saturation);

		_finishCommandPacket();
	}



		// *********************************
		// **
		// ** Implementations in ATEMuni.c:
		// **
		// *********************************



		// *********************************
		// **
		// ** Implementations in ATEMuni.c:
		// **
		// *********************************

		void ATEMuni::_parseGetCommands(const char *cmdStr)	{
			uint8_t multiViewer,windowIndex,mE,keyer,aUXChannel,input,mediaPlayer,stillBank,macroIndex,box;
			uint16_t videoSource,index,audioSource,sources;
			long temp;
			uint8_t readBytesForTlSr;

			if (!strcmp_P(cmdStr, PSTR("AMLv")))	{
				_readToPacketBuffer(36);
			} else if (!strcmp_P(cmdStr, PSTR("TlSr")))	{
				readBytesForTlSr = ((ATEM_packetBufferLength-2)/3)*3+2;
				_readToPacketBuffer(readBytesForTlSr);
			} else {
				_readToPacketBuffer();	// Default
			}


			if (!strcmp_P(cmdStr, PSTR("_pin")))	{
				if (_packetBuffer[5]=='T')	{
						_ATEMmodel = 0;
				} else
				if (_packetBuffer[5]=='1')	{
						_ATEMmodel = _packetBuffer[29]=='4' ? 4 : 1;
				} else
				if (_packetBuffer[5]=='2')	{
					_ATEMmodel = _packetBuffer[29]=='4' ? 5 : 2;
				} else
				if (_packetBuffer[5]=='P')	{
						_ATEMmodel = 3;
				}

				#if ATEM_debug
				if (_serialOutput>0)	{
					Serial.print(F("Switcher type: "));
					Serial.print(_ATEMmodel);
					switch(_ATEMmodel)	{
						case 0:
							Serial.println(F(" - TeleVision Studio"));
						break;
						case 1:
							Serial.println(F(" - ATEM 1 M/E"));
						break;
						case 2:
							Serial.println(F(" - ATEM 2 M/E"));
						break;
						case 3:
							Serial.println(F(" - ATEM Production Studio 4K"));
						break;
						case 4:
							Serial.println(F(" - ATEM 1 M/E 4K"));
						break;
						case 5:
							Serial.println(F(" - ATEM 2 M/E 4K"));
						break;
					}
				}
				#endif
			}

			
			if(!strcmp_P(cmdStr, PSTR("_pin"))) {
				
					memset(atemProductIdName,0,45);
					strncpy(atemProductIdName, (char *)(_packetBuffer+0), 44);
					#if ATEM_debug
					if ((_serialOutput==0x80 && hasInitialized()) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemProductIdName = "));
						Serial.println(atemProductIdName);
					}
					#endif
	
			}
			if(!strcmp_P(cmdStr, PSTR("_top"))) {
				

					
					#if ATEM_debug
					temp = atemTopologySources;
					#endif
					atemTopologySources = _packetBuffer[1];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTopologySources!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTopologySources = "));
						Serial.println(atemTopologySources);
					}
					#endif
					
			}

			
			if(!strcmp_P(cmdStr, PSTR("InPr"))) {
				videoSource = word(_packetBuffer[0],_packetBuffer[1]);
				if (getVideoSrcIndex(videoSource)<=46) {
					memset(atemInputLongName[getVideoSrcIndex(videoSource)],0,21);
					strncpy(atemInputLongName[getVideoSrcIndex(videoSource)], (char *)(_packetBuffer+2), 20);
					#if ATEM_debug
					if ((_serialOutput==0x80 && hasInitialized()) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemInputLongName[getVideoSrcIndex(videoSource)=")); Serial.print(getVideoSrcIndex(videoSource)); Serial.print(F("] = "));
						Serial.println(atemInputLongName[getVideoSrcIndex(videoSource)]);
					}
					#endif
					
					memset(atemInputShortName[getVideoSrcIndex(videoSource)],0,5);
					strncpy(atemInputShortName[getVideoSrcIndex(videoSource)], (char *)(_packetBuffer+22), 4);
					#if ATEM_debug
					if ((_serialOutput==0x80 && hasInitialized()) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemInputShortName[getVideoSrcIndex(videoSource)=")); Serial.print(getVideoSrcIndex(videoSource)); Serial.print(F("] = "));
						Serial.println(atemInputShortName[getVideoSrcIndex(videoSource)]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemInputAvailability[getVideoSrcIndex(videoSource)];
					#endif
					atemInputAvailability[getVideoSrcIndex(videoSource)] = _packetBuffer[34];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemInputAvailability[getVideoSrcIndex(videoSource)]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemInputAvailability[getVideoSrcIndex(videoSource)=")); Serial.print(getVideoSrcIndex(videoSource)); Serial.print(F("] = "));
						Serial.println(atemInputAvailability[getVideoSrcIndex(videoSource)]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemInputMEAvailability[getVideoSrcIndex(videoSource)];
					#endif
					atemInputMEAvailability[getVideoSrcIndex(videoSource)] = _packetBuffer[35];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemInputMEAvailability[getVideoSrcIndex(videoSource)]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemInputMEAvailability[getVideoSrcIndex(videoSource)=")); Serial.print(getVideoSrcIndex(videoSource)); Serial.print(F("] = "));
						Serial.println(atemInputMEAvailability[getVideoSrcIndex(videoSource)]);
					}
					#endif
					
				}
			} else 
			if(!strcmp_P(cmdStr, PSTR("MvIn"))) {
				
				multiViewer = _packetBuffer[0];
				windowIndex = _packetBuffer[1];
				if (multiViewer<=1 && windowIndex<=9) {
					#if ATEM_debug
					temp = atemMultiViewerInputVideoSource[multiViewer][windowIndex];
					#endif
					atemMultiViewerInputVideoSource[multiViewer][windowIndex] = word(_packetBuffer[2], _packetBuffer[3]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemMultiViewerInputVideoSource[multiViewer][windowIndex]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemMultiViewerInputVideoSource[multiViewer=")); Serial.print(multiViewer); Serial.print(F("][windowIndex=")); Serial.print(windowIndex); Serial.print(F("] = "));
						Serial.println(atemMultiViewerInputVideoSource[multiViewer][windowIndex]);
					}
					#endif
					
				}
			} else 
			if(!strcmp_P(cmdStr, PSTR("PrgI"))) {
				
				mE = _packetBuffer[0];
				if (mE<=1) {
					#if ATEM_debug
					temp = atemProgramInputVideoSource[mE];
					#endif
					atemProgramInputVideoSource[mE] = word(_packetBuffer[2], _packetBuffer[3]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemProgramInputVideoSource[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemProgramInputVideoSource[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemProgramInputVideoSource[mE]);
					}
					#endif
					
				}
			} else 
			if(!strcmp_P(cmdStr, PSTR("PrvI"))) {
				
				mE = _packetBuffer[0];
				if (mE<=1) {
					#if ATEM_debug
					temp = atemPreviewInputVideoSource[mE];
					#endif
					atemPreviewInputVideoSource[mE] = word(_packetBuffer[2], _packetBuffer[3]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemPreviewInputVideoSource[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemPreviewInputVideoSource[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemPreviewInputVideoSource[mE]);
					}
					#endif
					
				}
			} else 
			if(!strcmp_P(cmdStr, PSTR("TrSS"))) {
				
				mE = _packetBuffer[0];
				if (mE<=1) {
					#if ATEM_debug
					temp = atemTransitionStyle[mE];
					#endif
					atemTransitionStyle[mE] = _packetBuffer[1];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionStyle[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionStyle[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionStyle[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemTransitionNextTransition[mE];
					#endif
					atemTransitionNextTransition[mE] = _packetBuffer[2];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionNextTransition[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionNextTransition[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionNextTransition[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemTransitionStyleNext[mE];
					#endif
					atemTransitionStyleNext[mE] = _packetBuffer[3];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionStyleNext[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionStyleNext[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionStyleNext[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemTransitionNextTransitionNext[mE];
					#endif
					atemTransitionNextTransitionNext[mE] = _packetBuffer[4];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionNextTransitionNext[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionNextTransitionNext[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionNextTransitionNext[mE]);
					}
					#endif
					
				}
			} else 
			if(!strcmp_P(cmdStr, PSTR("TrPs"))) {
				
				mE = _packetBuffer[0];
				if (mE<=1) {
					#if ATEM_debug
					temp = atemTransitionInTransition[mE];
					#endif
					atemTransitionInTransition[mE] = _packetBuffer[1];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionInTransition[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionInTransition[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionInTransition[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemTransitionFramesRemaining[mE];
					#endif
					atemTransitionFramesRemaining[mE] = _packetBuffer[2];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionFramesRemaining[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionFramesRemaining[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionFramesRemaining[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemTransitionPosition[mE];
					#endif
					atemTransitionPosition[mE] = word(_packetBuffer[4], _packetBuffer[5]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionPosition[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionPosition[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionPosition[mE]);
					}
					#endif
					
				}
			} else 
			if(!strcmp_P(cmdStr, PSTR("TMxP"))) {
				
				mE = _packetBuffer[0];
				if (mE<=1) {
					#if ATEM_debug
					temp = atemTransitionMixRate[mE];
					#endif
					atemTransitionMixRate[mE] = _packetBuffer[1];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionMixRate[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionMixRate[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionMixRate[mE]);
					}
					#endif
					
				}
			} else 
			if(!strcmp_P(cmdStr, PSTR("TDpP"))) {
				
				mE = _packetBuffer[0];
				if (mE<=1) {
					#if ATEM_debug
					temp = atemTransitionDipRate[mE];
					#endif
					atemTransitionDipRate[mE] = _packetBuffer[1];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionDipRate[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionDipRate[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionDipRate[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemTransitionDipInput[mE];
					#endif
					atemTransitionDipInput[mE] = word(_packetBuffer[2], _packetBuffer[3]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionDipInput[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionDipInput[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionDipInput[mE]);
					}
					#endif
					
				}
			} else 
			if(!strcmp_P(cmdStr, PSTR("TWpP"))) {
				
				mE = _packetBuffer[0];
				if (mE<=1) {
					#if ATEM_debug
					temp = atemTransitionWipeRate[mE];
					#endif
					atemTransitionWipeRate[mE] = _packetBuffer[1];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionWipeRate[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionWipeRate[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionWipeRate[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemTransitionWipePattern[mE];
					#endif
					atemTransitionWipePattern[mE] = _packetBuffer[2];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionWipePattern[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionWipePattern[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionWipePattern[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemTransitionWipeWidth[mE];
					#endif
					atemTransitionWipeWidth[mE] = word(_packetBuffer[4], _packetBuffer[5]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionWipeWidth[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionWipeWidth[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionWipeWidth[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemTransitionWipeFillSource[mE];
					#endif
					atemTransitionWipeFillSource[mE] = word(_packetBuffer[6], _packetBuffer[7]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionWipeFillSource[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionWipeFillSource[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionWipeFillSource[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemTransitionWipeSymmetry[mE];
					#endif
					atemTransitionWipeSymmetry[mE] = word(_packetBuffer[8], _packetBuffer[9]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionWipeSymmetry[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionWipeSymmetry[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionWipeSymmetry[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemTransitionWipeSoftness[mE];
					#endif
					atemTransitionWipeSoftness[mE] = word(_packetBuffer[10], _packetBuffer[11]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionWipeSoftness[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionWipeSoftness[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionWipeSoftness[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemTransitionWipePositionX[mE];
					#endif
					atemTransitionWipePositionX[mE] = word(_packetBuffer[12], _packetBuffer[13]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionWipePositionX[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionWipePositionX[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionWipePositionX[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemTransitionWipePositionY[mE];
					#endif
					atemTransitionWipePositionY[mE] = word(_packetBuffer[14], _packetBuffer[15]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionWipePositionY[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionWipePositionY[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionWipePositionY[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemTransitionWipeReverse[mE];
					#endif
					atemTransitionWipeReverse[mE] = _packetBuffer[16];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionWipeReverse[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionWipeReverse[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionWipeReverse[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemTransitionWipeFlipFlop[mE];
					#endif
					atemTransitionWipeFlipFlop[mE] = _packetBuffer[17];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTransitionWipeFlipFlop[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTransitionWipeFlipFlop[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemTransitionWipeFlipFlop[mE]);
					}
					#endif
					
				}
			} else
			if(!strcmp_P(cmdStr, PSTR("KeOn"))) {
				
				mE = _packetBuffer[0];
				keyer = _packetBuffer[1];
				if (mE<=1 && keyer<=3) {
					#if ATEM_debug
					temp = atemKeyerOnAirEnabled[mE][keyer];
					#endif
					atemKeyerOnAirEnabled[mE][keyer] = _packetBuffer[2];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemKeyerOnAirEnabled[mE][keyer]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemKeyerOnAirEnabled[mE=")); Serial.print(mE); Serial.print(F("][keyer=")); Serial.print(keyer); Serial.print(F("] = "));
						Serial.println(atemKeyerOnAirEnabled[mE][keyer]);
					}
					#endif
					
				}
			} else
			if(!strcmp_P(cmdStr, PSTR("FtbP"))) {
				
				mE = _packetBuffer[0];
				if (mE<=1) {
					#if ATEM_debug
					temp = atemFadeToBlackRate[mE];
					#endif
					atemFadeToBlackRate[mE] = _packetBuffer[1];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemFadeToBlackRate[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemFadeToBlackRate[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemFadeToBlackRate[mE]);
					}
					#endif
					
				}
			} else 
			if(!strcmp_P(cmdStr, PSTR("FtbS"))) {
				
				mE = _packetBuffer[0];
				if (mE<=1) {
					#if ATEM_debug
					temp = atemFadeToBlackStateFullyBlack[mE];
					#endif
					atemFadeToBlackStateFullyBlack[mE] = _packetBuffer[1];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemFadeToBlackStateFullyBlack[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemFadeToBlackStateFullyBlack[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemFadeToBlackStateFullyBlack[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemFadeToBlackStateInTransition[mE];
					#endif
					atemFadeToBlackStateInTransition[mE] = _packetBuffer[2];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemFadeToBlackStateInTransition[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemFadeToBlackStateInTransition[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemFadeToBlackStateInTransition[mE]);
					}
					#endif
					
					#if ATEM_debug
					temp = atemFadeToBlackStateFramesRemaining[mE];
					#endif
					atemFadeToBlackStateFramesRemaining[mE] = _packetBuffer[3];
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemFadeToBlackStateFramesRemaining[mE]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemFadeToBlackStateFramesRemaining[mE=")); Serial.print(mE); Serial.print(F("] = "));
						Serial.println(atemFadeToBlackStateFramesRemaining[mE]);
					}
					#endif
					
				}
			} else 
			if(!strcmp_P(cmdStr, PSTR("AuxS"))) {
				
				aUXChannel = _packetBuffer[0];
				if (aUXChannel<=5) {
					#if ATEM_debug
					temp = atemAuxSourceInput[aUXChannel];
					#endif
					atemAuxSourceInput[aUXChannel] = word(_packetBuffer[2], _packetBuffer[3]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemAuxSourceInput[aUXChannel]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemAuxSourceInput[aUXChannel=")); Serial.print(aUXChannel); Serial.print(F("] = "));
						Serial.println(atemAuxSourceInput[aUXChannel]);
					}
					#endif
					
				}
			} else 
			if(!strcmp_P(cmdStr, PSTR("CCdP"))) {
				
				input = _packetBuffer[0];
				if (input<=20) {



				if (_packetBuffer[1]==0 && _packetBuffer[2]==2)	{
					
					#if ATEM_debug
					temp = atemCameraControlIris[input];
					#endif 

					atemCameraControlIris[input] = map((int16_t) word(_packetBuffer[16], _packetBuffer[17]), 22528, 1024, 2048, 0);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlIris[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlIris[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlIris[input]);
					}
					#endif
					
				}
				if (_packetBuffer[1]==0 && _packetBuffer[2]==3)	{
					
					#if ATEM_debug
					temp = atemCameraControlIris[input];
					#endif
					atemCameraControlIris[input] = (int16_t) word(_packetBuffer[16], _packetBuffer[17]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlIris[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlIris[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlIris[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==0 && _packetBuffer[2]==0)	{
					
					#if ATEM_debug
					temp = atemCameraControlFocus[input];
					#endif
					atemCameraControlFocus[input] = (int16_t) word(_packetBuffer[16], _packetBuffer[17]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlFocus[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlFocus[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlFocus[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==1 && _packetBuffer[2]==13)	{
					
					#if ATEM_debug
					temp = atemCameraControlGain[input];
					#endif
					atemCameraControlGain[input] = (int16_t) word(_packetBuffer[16], _packetBuffer[17]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlGain[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlGain[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlGain[input]);
					}
					#endif
					
				}

				
				if (_packetBuffer[1]==1 && _packetBuffer[2]==2)	{
					
					#if ATEM_debug
					temp = atemCameraControlWhiteBalance[input];
					#endif
					atemCameraControlWhiteBalance[input] = (int16_t) word(_packetBuffer[16], _packetBuffer[17]);
					atemCameraControlTint[input] = (int16_t) word(_packetBuffer[18], _packetBuffer[19]);

					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlWhiteBalance[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlWhiteBalance[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlWhiteBalance[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==1 && _packetBuffer[2]==8)	{
					
					#if ATEM_debug
					temp = atemCameraControlSharpeningLevel[input];
					#endif
					atemCameraControlSharpeningLevel[input] = (int16_t) word(_packetBuffer[16], _packetBuffer[16]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlSharpeningLevel[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlSharpeningLevel[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlSharpeningLevel[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==0 && _packetBuffer[2]==8)	{
					
					#if ATEM_debug
					temp = atemCameraControlZoomNormalized[input];
					#endif
					atemCameraControlZoomNormalized[input] = (int16_t) word(_packetBuffer[16], _packetBuffer[17]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlZoomNormalized[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlZoomNormalized[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlZoomNormalized[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==0 && _packetBuffer[2]==9)	{
					
					#if ATEM_debug
					temp = atemCameraControlZoomSpeed[input];
					#endif
					atemCameraControlZoomSpeed[input] = (int16_t) word(_packetBuffer[16], _packetBuffer[17]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlZoomSpeed[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlZoomSpeed[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlZoomSpeed[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==4 && _packetBuffer[2]==4)	{
					
					#if ATEM_debug
					temp = atemCameraControlColorbars[input];
					#endif
					atemCameraControlColorbars[input] = (int16_t) word(_packetBuffer[16], _packetBuffer[17]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlColorbars[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlColorbars[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlColorbars[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==8 && _packetBuffer[2]==0)	{
					
					#if ATEM_debug
					temp = atemCameraControlLiftR[input];
					#endif
					atemCameraControlLiftR[input] = (int16_t) word(_packetBuffer[16], _packetBuffer[17]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlLiftR[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlLiftR[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlLiftR[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==8 && _packetBuffer[2]==1)	{
					
					#if ATEM_debug
					temp = atemCameraControlGammaR[input];
					#endif
					atemCameraControlGammaR[input] = (int16_t) word(_packetBuffer[16], _packetBuffer[17]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlGammaR[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlGammaR[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlGammaR[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==8 && _packetBuffer[2]==2)	{
					
					#if ATEM_debug
					temp = atemCameraControlGainR[input];
					#endif
					atemCameraControlGainR[input] = (int16_t) word(_packetBuffer[16], _packetBuffer[17]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlGainR[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlGainR[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlGainR[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==8 && _packetBuffer[2]==5)	{
					
					#if ATEM_debug
					temp = atemCameraControlLumMix[input];
					#endif
					atemCameraControlLumMix[input] = (int16_t) word(_packetBuffer[16], _packetBuffer[17]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlLumMix[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlLumMix[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlLumMix[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==8 && _packetBuffer[2]==6)	{
					
					#if ATEM_debug
					temp = atemCameraControlHue[input];
					#endif
					atemCameraControlHue[input] = (int16_t) word(_packetBuffer[16], _packetBuffer[17]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlHue[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlHue[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlHue[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==1 && _packetBuffer[2]==5)	{
					
					#if ATEM_debug
					temp = atemCameraControlShutter[input];
					#endif
					atemCameraControlShutter[input] = (int16_t) word(_packetBuffer[18], _packetBuffer[19]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlShutter[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlShutter[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlShutter[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==8 && _packetBuffer[2]==0)	{
					
					#if ATEM_debug
					temp = atemCameraControlLiftG[input];
					#endif
					atemCameraControlLiftG[input] = (int16_t) word(_packetBuffer[18], _packetBuffer[19]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlLiftG[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlLiftG[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlLiftG[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==8 && _packetBuffer[2]==1)	{
					
					#if ATEM_debug
					temp = atemCameraControlGammaG[input];
					#endif
					atemCameraControlGammaG[input] = (int16_t) word(_packetBuffer[18], _packetBuffer[19]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlGammaG[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlGammaG[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlGammaG[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==8 && _packetBuffer[2]==2)	{
					
					#if ATEM_debug
					temp = atemCameraControlGainG[input];
					#endif
					atemCameraControlGainG[input] = (int16_t) word(_packetBuffer[18], _packetBuffer[19]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlGainG[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlGainG[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlGainG[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==8 && _packetBuffer[2]==4)	{
					
					#if ATEM_debug
					temp = atemCameraControlContrast[input];
					#endif
					atemCameraControlPivot[input] = (int16_t) word(_packetBuffer[16], _packetBuffer[17]);
					atemCameraControlContrast[input] = (int16_t) word(_packetBuffer[18], _packetBuffer[19]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlContrast[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlContrast[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlContrast[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==8 && _packetBuffer[2]==6)	{
					
					#if ATEM_debug
					temp = atemCameraControlSaturation[input];
					#endif
					atemCameraControlSaturation[input] = (int16_t) word(_packetBuffer[18], _packetBuffer[19]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlSaturation[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlSaturation[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlSaturation[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==8 && _packetBuffer[2]==0)	{
					
					#if ATEM_debug
					temp = atemCameraControlLiftB[input];
					#endif
					atemCameraControlLiftB[input] = (int16_t) word(_packetBuffer[20], _packetBuffer[21]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlLiftB[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlLiftB[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlLiftB[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==8 && _packetBuffer[2]==1)	{
					
					#if ATEM_debug
					temp = atemCameraControlGammaB[input];
					#endif
					atemCameraControlGammaB[input] = (int16_t) word(_packetBuffer[20], _packetBuffer[21]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlGammaB[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlGammaB[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlGammaB[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==8 && _packetBuffer[2]==2)	{
					
					#if ATEM_debug
					temp = atemCameraControlGainB[input];
					#endif
					atemCameraControlGainB[input] = (int16_t) word(_packetBuffer[20], _packetBuffer[21]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlGainB[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlGainB[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlGainB[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==8 && _packetBuffer[2]==0)	{
					
					#if ATEM_debug
					temp = atemCameraControlLiftY[input];
					#endif
					atemCameraControlLiftY[input] = (int16_t) word(_packetBuffer[22], _packetBuffer[23]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlLiftY[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlLiftY[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlLiftY[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==8 && _packetBuffer[2]==1)	{
					
					#if ATEM_debug
					temp = atemCameraControlGammaY[input];
					#endif
					atemCameraControlGammaY[input] = (int16_t) word(_packetBuffer[22], _packetBuffer[23]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlGammaY[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlGammaY[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlGammaY[input]);
					}
					#endif
					
				}
				
				if (_packetBuffer[1]==8 && _packetBuffer[2]==2)	{
					
					#if ATEM_debug
					temp = atemCameraControlGainY[input];
					#endif
					atemCameraControlGainY[input] = (int16_t) word(_packetBuffer[22], _packetBuffer[23]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemCameraControlGainY[input]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemCameraControlGainY[input=")); Serial.print(input); Serial.print(F("] = "));
						Serial.println(atemCameraControlGainY[input]);
					}
					#endif
					
				}
				
				}
			} else 
			if(!strcmp_P(cmdStr, PSTR("TlSr"))) {
				
				sources = word(_packetBuffer[0],_packetBuffer[1]);
				if (sources<=46) {
					#if ATEM_debug
					temp = atemTallyBySourceSources;
					#endif
					atemTallyBySourceSources = word(_packetBuffer[0], _packetBuffer[1]);
					#if ATEM_debug
					if ((_serialOutput==0x80 && atemTallyBySourceSources!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
						Serial.print(F("atemTallyBySourceSources = "));
						Serial.println(atemTallyBySourceSources);
					}
					#endif

					int readComp = 2;
					for(uint8_t a=0;a<sources;a++)	{
						if (2+(3*a) == readBytesForTlSr)	{
							readComp-=readBytesForTlSr;
							_readToPacketBuffer();
						}

						#if ATEM_debug
						temp = atemTallyBySourceVideoSource[a];
						#endif
						atemTallyBySourceVideoSource[a] = word(_packetBuffer[readComp+(3*a)], _packetBuffer[readComp+(3*a)+1]);
						#if ATEM_debug
						if ((_serialOutput==0x80 && atemTallyBySourceVideoSource[a]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
							Serial.print(F("atemTallyBySourceVideoSource[a=")); Serial.print(a); Serial.print(F("] = "));
							Serial.println(atemTallyBySourceVideoSource[a]);
						}
						#endif

						#if ATEM_debug
						temp = atemTallyBySourceTallyFlags[a];
						#endif
						atemTallyBySourceTallyFlags[a] = _packetBuffer[readComp+(3*a)+2];
						#if ATEM_debug
						if ((_serialOutput==0x80 && atemTallyBySourceTallyFlags[a]!=temp) || (_serialOutput==0x81 && !hasInitialized()))	{
							Serial.print(F("atemTallyBySourceTallyFlags[a=")); Serial.print(a); Serial.print(F("] = "));
							Serial.println(atemTallyBySourceTallyFlags[a]);
						}
						#endif
					}

		
				}
			} else 
			{}
		}

			/**
			 * Get Product Id; Name
			 */
			char *  ATEMuni::getProductIdName() {
				return atemProductIdName;
			}
			
			/**
			 * Get Topology; Sources
			 */
			uint8_t ATEMuni::getTopologySources() {
				return atemTopologySources;
			}

			/**
			 * Get Input Properties; Long Name
			 * videoSource 	(See video source list)
			 */
			char *  ATEMuni::getInputLongName(uint16_t videoSource) {
				return atemInputLongName[getVideoSrcIndex(videoSource)];
			}
			
			/**
			 * Get Input Properties; Short Name
			 * videoSource 	(See video source list)
			 */
			char *  ATEMuni::getInputShortName(uint16_t videoSource) {
				return atemInputShortName[getVideoSrcIndex(videoSource)];
			}
			
			/**
			 * Get Input Properties; Availability
			 * videoSource 	(See video source list)
			 */
			uint8_t ATEMuni::getInputAvailability(uint16_t videoSource) {
				return atemInputAvailability[getVideoSrcIndex(videoSource)];
			}
			
			/**
			 * Get Input Properties; ME Availability
			 * videoSource 	(See video source list)
			 */
			uint8_t ATEMuni::getInputMEAvailability(uint16_t videoSource) {
				return atemInputMEAvailability[getVideoSrcIndex(videoSource)];
			}
			
			/**
			 * Get Program Input; Video Source
			 * mE 	0: ME1, 1: ME2
			 */
			uint16_t ATEMuni::getProgramInputVideoSource(uint8_t mE) {
				return atemProgramInputVideoSource[mE];
			}
			
			/**
			 * Set Program Input; Video Source
			 * mE 	0: ME1, 1: ME2
			 * videoSource 	(See video source list)
			 */
			void ATEMuni::setProgramInputVideoSource(uint8_t mE, uint16_t videoSource) {
			
	  	  		_prepareCommandPacket(PSTR("CPgI"),4,(_packetBuffer[12+_cBBO+4+4+0]==mE));
		
				_packetBuffer[12+_cBBO+4+4+0] = mE;
				
				_packetBuffer[12+_cBBO+4+4+2] = highByte(videoSource);
				_packetBuffer[12+_cBBO+4+4+3] = lowByte(videoSource);
				
	 	   		_finishCommandPacket();
		
			}
			
			/**
			 * Get Preview Input; Video Source
			 * mE 	0: ME1, 1: ME2
			 */
			uint16_t ATEMuni::getPreviewInputVideoSource(uint8_t mE) {
				return atemPreviewInputVideoSource[mE];
			}
			
			/**
			 * Set Preview Input; Video Source
			 * mE 	0: ME1, 1: ME2
			 * videoSource 	(See video source list)
			 */
			void ATEMuni::setPreviewInputVideoSource(uint8_t mE, uint16_t videoSource) {
			
	  	  		_prepareCommandPacket(PSTR("CPvI"),4,(_packetBuffer[12+_cBBO+4+4+0]==mE));
		
				_packetBuffer[12+_cBBO+4+4+0] = mE;
				
				_packetBuffer[12+_cBBO+4+4+2] = highByte(videoSource);
				_packetBuffer[12+_cBBO+4+4+3] = lowByte(videoSource);
				
	 	   		_finishCommandPacket();
		
			}
			
			/**
			 * Set Cut; M/E
			 * mE 	0: ME1, 1: ME2
			 */
			void ATEMuni::performCutME(uint8_t mE) {
	  	  		
				_prepareCommandPacket(PSTR("DCut"),4);
		
				_packetBuffer[12+_cBBO+4+4+0] = mE;
				

	 	   		_finishCommandPacket();
		
			}
			
			/**
			 * Set Auto; M/E
			 * mE 	0: ME1, 1: ME2
			 */
			void ATEMuni::performAutoME(uint8_t mE) {
			
	  	  		_prepareCommandPacket(PSTR("DAut"),4);
		
				_packetBuffer[12+_cBBO+4+4+0] = mE;
				
	 	   		_finishCommandPacket();
		
			}

			
			/**
			 * Get Fade-To-Black; Rate
			 * mE 	0: ME1, 1: ME2
			 */
			uint8_t ATEMuni::getFadeToBlackRate(uint8_t mE) {
				return atemFadeToBlackRate[mE];
			}
			
			/**
			 * Set Fade-To-Black; Rate
			 * mE 	0: ME1, 1: ME2
			 * rate 	1-250: Frames
			 */
			void ATEMuni::setFadeToBlackRate(uint8_t mE, uint8_t rate) {
			
	  	  		_prepareCommandPacket(PSTR("FtbC"),4,(_packetBuffer[12+_cBBO+4+4+1]==mE));
		
					// Set Mask: 1
				_packetBuffer[12+_cBBO+4+4+0] |= 1;
						
				_packetBuffer[12+_cBBO+4+4+1] = mE;
				
				_packetBuffer[12+_cBBO+4+4+2] = rate;
				
	 	   		_finishCommandPacket();
		
			}
			
			/**
			 * Get Fade-To-Black State; Fully Black
			 * mE 	0: ME1, 1: ME2
			 */
			bool ATEMuni::getFadeToBlackStateFullyBlack(uint8_t mE) {
				return atemFadeToBlackStateFullyBlack[mE];
			}
			
			/**
			 * Get Fade-To-Black State; In Transition
			 * mE 	0: ME1, 1: ME2
			 */
			bool ATEMuni::getFadeToBlackStateInTransition(uint8_t mE) {
				return atemFadeToBlackStateInTransition[mE];
			}
			
			/**
			 * Get Fade-To-Black State; Frames Remaining
			 * mE 	0: ME1, 1: ME2
			 */
			uint8_t ATEMuni::getFadeToBlackStateFramesRemaining(uint8_t mE) {
				return atemFadeToBlackStateFramesRemaining[mE];
			}
			


				/**
				 * Set Fade-To-Black; M/E
				 * mE 	0: ME1, 1: ME2
				 */
				void ATEMuni::performFadeToBlackME(uint8_t mE) {

		  	  		_prepareCommandPacket(PSTR("FtbA"),4);

					_packetBuffer[12+_cBBO+4+4+0] = mE;
					_packetBuffer[12+_cBBO+4+4+1] = 0x02;

					_finishCommandPacket();

				}
			
			/**
			 * Get Aux Source; Input
			 * aUXChannel 	0-5: Aux 1-6
			 */
			uint16_t ATEMuni::getAuxSourceInput(uint8_t aUXChannel) {
				return atemAuxSourceInput[aUXChannel];
			}
			
			/**
			 * Set Aux Source; Input
			 * aUXChannel 	0-5: Aux 1-6
			 * input 	(See video source list)
			 */
			void ATEMuni::setAuxSourceInput(uint8_t aUXChannel, uint16_t input) {
			
	  	  		_prepareCommandPacket(PSTR("CAuS"),4,(_packetBuffer[12+_cBBO+4+4+1]==aUXChannel));
		
					// Set Mask: 1
				_packetBuffer[12+_cBBO+4+4+0] |= 1;
						
				_packetBuffer[12+_cBBO+4+4+1] = aUXChannel;
				
				_packetBuffer[12+_cBBO+4+4+2] = highByte(input);
				_packetBuffer[12+_cBBO+4+4+3] = lowByte(input);
				
	 	   		_finishCommandPacket();
		
			}
			
			/**
			 * Get Camera Control; Iris
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlIris(uint8_t input) {
				return atemCameraControlIris[input];
			}
			
			/**
			 * Get Camera Control; Focus
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlFocus(uint8_t input) {
				return atemCameraControlFocus[input];
			}
			
			/**
			 * Get Camera Control; Gain
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlGain(uint8_t input) {
				return atemCameraControlGain[input];
			}
			
			/**
			 * Get Camera Control; White Balance
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlWhiteBalance(uint8_t input) {
				return atemCameraControlWhiteBalance[input];
			}
			
			int16_t ATEMuni::getCameraControlTint(uint8_t input) {
				return atemCameraControlTint[input];
			}
			
			/**
			 * Get Camera Control; Sharpening Level
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlSharpeningLevel(uint8_t input) {
				return atemCameraControlSharpeningLevel[input];
			}
			
			/**
			 * Get Camera Control; Zoom Normalized
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlZoomNormalized(uint8_t input) {
				return atemCameraControlZoomNormalized[input];
			}
			
			/**
			 * Get Camera Control; Zoom Speed
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlZoomSpeed(uint8_t input) {
				return atemCameraControlZoomSpeed[input];
			}
			
			/**
			 * Get Camera Control; Colorbars
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlColorbars(uint8_t input) {
				return atemCameraControlColorbars[input];
			}
			
			/**
			 * Get Camera Control; Lift R
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlLiftR(uint8_t input) {
				return atemCameraControlLiftR[input];
			}
			
			/**
			 * Get Camera Control; Gamma R
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlGammaR(uint8_t input) {
				return atemCameraControlGammaR[input];
			}
			
			/**
			 * Get Camera Control; Gain R
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlGainR(uint8_t input) {
				return atemCameraControlGainR[input];
			}
			
			/**
			 * Get Camera Control; Lum Mix
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlLumMix(uint8_t input) {
				return atemCameraControlLumMix[input];
			}
			
			/**
			 * Get Camera Control; Hue
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlHue(uint8_t input) {
				return atemCameraControlHue[input];
			}
			
			/**
			 * Get Camera Control; Shutter
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlShutter(uint8_t input) {
				return atemCameraControlShutter[input];
			}
			
			/**
			 * Get Camera Control; Lift G
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlLiftG(uint8_t input) {
				return atemCameraControlLiftG[input];
			}
			
			/**
			 * Get Camera Control; Gamma G
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlGammaG(uint8_t input) {
				return atemCameraControlGammaG[input];
			}
			
			/**
			 * Get Camera Control; Gain G
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlGainG(uint8_t input) {
				return atemCameraControlGainG[input];
			}
			
			/**
			 * Get Camera Control; Contrast
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlContrast(uint8_t input) {
				return atemCameraControlContrast[input];
			}
			
			int16_t ATEMuni::getCameraControlPivot(uint8_t input) {
				return atemCameraControlPivot[input];
			}
			
			/**
			 * Get Camera Control; Saturation
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlSaturation(uint8_t input) {
				return atemCameraControlSaturation[input];
			}
			
			/**
			 * Get Camera Control; Lift B
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlLiftB(uint8_t input) {
				return atemCameraControlLiftB[input];
			}
			
			/**
			 * Get Camera Control; Gamma B
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlGammaB(uint8_t input) {
				return atemCameraControlGammaB[input];
			}
			
			/**
			 * Get Camera Control; Gain B
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlGainB(uint8_t input) {
				return atemCameraControlGainB[input];
			}
			
			/**
			 * Get Camera Control; Lift Y
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlLiftY(uint8_t input) {
				return atemCameraControlLiftY[input];
			}
			
			/**
			 * Get Camera Control; Gamma Y
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlGammaY(uint8_t input) {
				return atemCameraControlGammaY[input];
			}
			
			/**
			 * Get Camera Control; Gain Y
			 * input 	1-20: Camera
			 */
			int16_t ATEMuni::getCameraControlGainY(uint8_t input) {
				return atemCameraControlGainY[input];
			}
			

			/**
				* Set Camera Control; Auto iris
				* Command takes no input
				*/

			void ATEMuni::setCameraControlAutoIris(uint8_t input, int16_t autoiris) {
					_prepareCommandPacket(PSTR("CCmd"), 24);

					_packetBuffer[12+_cBBO+4+4+0] = input;

					_packetBuffer[12+_cBBO+4+4+1] = 0;
					_packetBuffer[12+_cBBO+4+4+2] = 5;

					_packetBuffer[12+_cBBO+4+4+4] = 0x00; // Data type: void

					_finishCommandPacket();
			}


			/**
				* Set Camera Control; Detail level
				* 0: Off, 1: Low, 2: Medium, 3: High
				*/

			void ATEMuni::setCameraControlSharpeningLevel(uint8_t input, int16_t detail) {
					_prepareCommandPacket(PSTR("CCmd"), 20);

					_packetBuffer[12+_cBBO+4+4+0] = input;

					_packetBuffer[12+_cBBO+4+4+1] = 1;
					_packetBuffer[12+_cBBO+4+4+2] = 8;

					_packetBuffer[12+_cBBO+4+4+4] = 0x01; // Data type: int8
					
					// Reduncancy: Support for ATEM Switchers & ATEM Proxy
					_packetBuffer[12+_cBBO+4+4+7] = 0x01;
					_packetBuffer[12+_cBBO+4+4+9] = 0x01;

					_packetBuffer[12+_cBBO+4+4+16] = detail & 0xFF;

					_finishCommandPacket();
			}

			/**
				* Set Camera Control; Auto focus
				* Command takes no input
				*/

			void ATEMuni::setCameraControlAutoFocus(uint8_t input, int16_t autoiris) {
					_prepareCommandPacket(PSTR("CCmd"), 24);

					_packetBuffer[12+_cBBO+4+4+0] = input;

					_packetBuffer[12+_cBBO+4+4+1] = 0;
					_packetBuffer[12+_cBBO+4+4+2] = 1;

					_packetBuffer[12+_cBBO+4+4+4] = 0x00; // Data type: void

					_finishCommandPacket();
			}

			/**
				* Set Camera Control; Reset all
				* Command takes no input
				*/

			void ATEMuni::setCameraControlResetAll(uint8_t input, int16_t reset) {
					_prepareCommandPacket(PSTR("CCmd"), 24);

					_packetBuffer[12+_cBBO+4+4+0] = input;

					_packetBuffer[12+_cBBO+4+4+1] = 8;
					_packetBuffer[12+_cBBO+4+4+2] = 7;

					_packetBuffer[12+_cBBO+4+4+4] = 0x00; // Data type: void

					_finishCommandPacket();

					// Update local state variables to reflect reset values
					atemCameraControlGammaY[input] = 0;
					atemCameraControlGammaR[input] = 0;
					atemCameraControlGammaG[input] = 0;
					atemCameraControlGammaB[input] = 0;

					atemCameraControlLiftY[input] = 0;
					atemCameraControlLiftR[input] = 0;
					atemCameraControlLiftG[input] = 0;
					atemCameraControlLiftB[input] = 0;

					atemCameraControlGainY[input] = 2048;
					atemCameraControlGainR[input] = 2048;
					atemCameraControlGainG[input] = 2048;
					atemCameraControlGainB[input] = 2048;

					atemCameraControlContrast[input] = 2048;
					atemCameraControlHue[input] = 0;
					atemCameraControlSaturation[input] = 2048;
			}

			/**
			 * Set Camera Control; Iris
			 * input 	0-7: Camera
			 * iris 	0-2048
			 */
			void ATEMuni::setCameraControlIris(uint8_t input, int16_t iris) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 0;
				_packetBuffer[12+_cBBO+4+4+2] = 2;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;	// Data type: 5.11 floating point
				_packetBuffer[12+_cBBO+4+4+9] = 0x01;	// One byte

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(iris);
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(iris);

				_finishCommandPacket();
			}

			/**
			 * Set Camera Control; Colorbars
			 * input 	0-7: Camera
			 * colorbars: duration in secs (0=disable)
			 */
			void ATEMuni::setCameraControlColorbars(uint8_t input, int16_t colorbars) {

		  		_prepareCommandPacket(PSTR("CCmd"), 20);

				_packetBuffer[12+_cBBO+4+4+0] = input;

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 4;
				_packetBuffer[12+_cBBO+4+4+2] = 4;

				_packetBuffer[12+_cBBO+4+4+4] = 0x01;	// Data type: int8
				
				// Reduncancy: Support for ATEM Switchers & ATEM Proxy
				_packetBuffer[12+_cBBO+4+4+7] = 0x01;
				_packetBuffer[12+_cBBO+4+4+9] = 0x01;


				_packetBuffer[12+_cBBO+4+4+16] = (colorbars & 0xFF);

				_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Focus
			 * input 	0-7: Camera
			 * focus 	0-65535
			 */
			void ATEMuni::setCameraControlFocus(uint8_t input, int16_t focus) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 0;
				_packetBuffer[12+_cBBO+4+4+2] = 0;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;	// Data type: 5.11 floating point
				_packetBuffer[12+_cBBO+4+4+9] = 0x01;	// One byte

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(focus);
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(focus);

		   		_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Gain
			 * input 	0-7: Camera
			 * gain 	512: 0db, 1024: 6db, 2048: 12db, 4096: 18db
			 */
			void ATEMuni::setCameraControlGain(uint8_t input, int16_t gain) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 1;
				_packetBuffer[12+_cBBO+4+4+2] = 1;

				_packetBuffer[12+_cBBO+4+4+4] = 0x01;

				// Reduncancy: Support for ATEM Switchers & ATEM Proxy
				_packetBuffer[12+_cBBO+4+4+7] = 0x01;
				_packetBuffer[12+_cBBO+4+4+9] = 0x01;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(gain);
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(gain);

		   		_finishCommandPacket();

			}

			/**
			 * Set Camera Control; White Balance
			 * input 	0-7: Camera
			 *
			 */
			void ATEMuni::setCameraControlWhiteBalance(uint8_t input, int16_t whiteBalance) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 1;
				_packetBuffer[12+_cBBO+4+4+2] = 2;

				_packetBuffer[12+_cBBO+4+4+4] = 0x02;
				_packetBuffer[12+_cBBO+4+4+9] = 0x01;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(whiteBalance);
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(whiteBalance);

		   		_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Zoom Normalized
			 * input 	0-7: Camera
			 *
			 */
			void ATEMuni::setCameraControlZoomNormalized(uint8_t input, int16_t zoomNormalized) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 0;
				_packetBuffer[12+_cBBO+4+4+2] = 8;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x01;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(zoomNormalized);
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(zoomNormalized);

		   		_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Zoom
			 * input 	0-7: Camera
			 *
			 */
			void ATEMuni::setCameraControlZoomSpeed(uint8_t input, int16_t zoomSpeed) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 0;
				_packetBuffer[12+_cBBO+4+4+2] = 9;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x01;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(zoomSpeed);
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(zoomSpeed);

		   		_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Lift R
			 * input 	0-7: Camera
			 * liftR 	-4096-4096: -1.00-1.00
			 */
			void ATEMuni::setCameraControlLiftR(uint8_t input, int16_t liftR) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 8;
				_packetBuffer[12+_cBBO+4+4+2] = 0;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x04;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(liftR);
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(liftR);

				_packetBuffer[12+_cBBO+4+4+18] = highByte(getCameraControlLiftG(input));
				_packetBuffer[12+_cBBO+4+4+19] = lowByte(getCameraControlLiftG(input));
				_packetBuffer[12+_cBBO+4+4+20] = highByte(getCameraControlLiftB(input));
				_packetBuffer[12+_cBBO+4+4+21] = lowByte(getCameraControlLiftB(input));
				_packetBuffer[12+_cBBO+4+4+22] = highByte(getCameraControlLiftY(input));
				_packetBuffer[12+_cBBO+4+4+23] = lowByte(getCameraControlLiftY(input));

		   		_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Gamma R
			 * input 	0-7: Camera
			 * gammaR 	-4096-4096: -1.00-1.00
			 */
			void ATEMuni::setCameraControlGammaR(uint8_t input, int16_t gammaR) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 8;
				_packetBuffer[12+_cBBO+4+4+2] = 1;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x04;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(gammaR);
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(gammaR);

				_packetBuffer[12+_cBBO+4+4+18] = highByte(getCameraControlGammaG(input));
				_packetBuffer[12+_cBBO+4+4+19] = lowByte(getCameraControlGammaG(input));
				_packetBuffer[12+_cBBO+4+4+20] = highByte(getCameraControlGammaB(input));
				_packetBuffer[12+_cBBO+4+4+21] = lowByte(getCameraControlGammaB(input));
				_packetBuffer[12+_cBBO+4+4+22] = highByte(getCameraControlGammaY(input));
				_packetBuffer[12+_cBBO+4+4+23] = lowByte(getCameraControlGammaY(input));


				_finishCommandPacket();
			}

			/**
			 * Set Camera Control; Gain R
			 * input 	0-7: Camera
			 * gainR 	-4096-4096: -1.00-1.00
			 */
			void ATEMuni::setCameraControlGainR(uint8_t input, int16_t gainR) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 8;
				_packetBuffer[12+_cBBO+4+4+2] = 2;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x04;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(gainR);
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(gainR);

				_packetBuffer[12+_cBBO+4+4+18] = highByte(getCameraControlGainG(input));
				_packetBuffer[12+_cBBO+4+4+19] = lowByte(getCameraControlGainG(input));
				_packetBuffer[12+_cBBO+4+4+20] = highByte(getCameraControlGainB(input));
				_packetBuffer[12+_cBBO+4+4+21] = lowByte(getCameraControlGainB(input));
				_packetBuffer[12+_cBBO+4+4+22] = highByte(getCameraControlGainY(input));
				_packetBuffer[12+_cBBO+4+4+23] = lowByte(getCameraControlGainY(input));

				_finishCommandPacket();
			}

			/**
			 * Set Camera Control; Lum Mix
			 * input 	0-7: Camera
			 * lumMix 	0-2048: 0-100%
			 */
			void ATEMuni::setCameraControlLumMix(uint8_t input, int16_t lumMix) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 8;
				_packetBuffer[12+_cBBO+4+4+2] = 5;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x01;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(lumMix);
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(lumMix);

				_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Hue
			 * input 	0-7: Camera
			 * hue 	-2048-2048: 0-360 degrees
			 */
			void ATEMuni::setCameraControlHue(uint8_t input, int16_t hue) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 8;
				_packetBuffer[12+_cBBO+4+4+2] = 6;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x02;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(hue);
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(hue);

				_packetBuffer[12+_cBBO+4+4+18] = highByte(getCameraControlSaturation(input));
				_packetBuffer[12+_cBBO+4+4+19] = lowByte(getCameraControlSaturation(input));

				_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Shutter
			 * input 	0-7: Camera
			 * shutter 	20000: 1/50, 16667: 1/60, 13333: 1/75, 11111: 1/90, 10000: 1/100, 8333: 1/120, 6667: 1/150, 5556: 1/180, 4000: 1/250, 2778: 1/360, 2000: 1/500, 1379: 1/750, 1000: 1/1000, 690: 1/1450, 500: 1/2000
			 */
			void ATEMuni::setCameraControlShutter(uint8_t input, int16_t shutter) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 1;
				_packetBuffer[12+_cBBO+4+4+2] = 5;

				_packetBuffer[12+_cBBO+4+4+4] = 0x03;
				_packetBuffer[12+_cBBO+4+4+11] = 0x01;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+18] = highByte(shutter);
				_packetBuffer[12+_cBBO+4+4+19] = lowByte(shutter);

				_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Lift G
			 * input 	0-7: Camera
			 * liftG 	-4096-4096: -1.00-1.00
			 */
			void ATEMuni::setCameraControlLiftG(uint8_t input, int16_t liftG) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 8;
				_packetBuffer[12+_cBBO+4+4+2] = 0;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x04;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(getCameraControlLiftR(input));
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(getCameraControlLiftR(input));

				_packetBuffer[12+_cBBO+4+4+18] = highByte(liftG);
				_packetBuffer[12+_cBBO+4+4+19] = lowByte(liftG);

				_packetBuffer[12+_cBBO+4+4+20] = highByte(getCameraControlLiftB(input));
				_packetBuffer[12+_cBBO+4+4+21] = lowByte(getCameraControlLiftB(input));
				_packetBuffer[12+_cBBO+4+4+22] = highByte(getCameraControlLiftY(input));
				_packetBuffer[12+_cBBO+4+4+23] = lowByte(getCameraControlLiftY(input));


				_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Gamma G
			 * input 	0-7: Camera
			 * gammaG 	-4096-4096: -1.00-1.00
			 */
			void ATEMuni::setCameraControlGammaG(uint8_t input, int16_t gammaG) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 8;
				_packetBuffer[12+_cBBO+4+4+2] = 1;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x04;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(getCameraControlGammaR(input));
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(getCameraControlGammaR(input));

				_packetBuffer[12+_cBBO+4+4+18] = highByte(gammaG);
				_packetBuffer[12+_cBBO+4+4+19] = lowByte(gammaG);

				_packetBuffer[12+_cBBO+4+4+20] = highByte(getCameraControlGammaB(input));
				_packetBuffer[12+_cBBO+4+4+21] = lowByte(getCameraControlGammaB(input));
				_packetBuffer[12+_cBBO+4+4+22] = highByte(getCameraControlGammaY(input));
				_packetBuffer[12+_cBBO+4+4+23] = lowByte(getCameraControlGammaY(input));

				_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Gain G
			 * input 	0-7: Camera
			 * gainG 	-4096-4096: -1.00-1.00
			 */
			void ATEMuni::setCameraControlGainG(uint8_t input, int16_t gainG) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 8;
				_packetBuffer[12+_cBBO+4+4+2] = 2;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x04;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(getCameraControlGainR(input));
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(getCameraControlGainR(input));

				_packetBuffer[12+_cBBO+4+4+18] = highByte(gainG);
				_packetBuffer[12+_cBBO+4+4+19] = lowByte(gainG);

				_packetBuffer[12+_cBBO+4+4+20] = highByte(getCameraControlGainB(input));
				_packetBuffer[12+_cBBO+4+4+21] = lowByte(getCameraControlGainB(input));
				_packetBuffer[12+_cBBO+4+4+22] = highByte(getCameraControlGainY(input));
				_packetBuffer[12+_cBBO+4+4+23] = lowByte(getCameraControlGainY(input));

				_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Contrast
			 * input 	0-7: Camera
			 * contrast 	0-4096: 0-100%
			 */
			void ATEMuni::setCameraControlContrast(uint8_t input, int16_t contrast) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 8;
				_packetBuffer[12+_cBBO+4+4+2] = 4;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x02;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				// Pivot = 0.5 (Fixed16 1024)
				_packetBuffer[12+_cBBO+4+4+16] = 4;
				_packetBuffer[12+_cBBO+4+4+17] = 0;

				_packetBuffer[12+_cBBO+4+4+18] = highByte(contrast);
				_packetBuffer[12+_cBBO+4+4+19] = lowByte(contrast);

				_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Saturation
			 * input 	0-7: Camera
			 * saturation 	0-4096: 0-100%
			 */
			void ATEMuni::setCameraControlSaturation(uint8_t input, int16_t saturation) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 8;
				_packetBuffer[12+_cBBO+4+4+2] = 6;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x02;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(getCameraControlHue(input));
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(getCameraControlHue(input));

				_packetBuffer[12+_cBBO+4+4+18] = highByte(saturation);
				_packetBuffer[12+_cBBO+4+4+19] = lowByte(saturation);

				_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Lift B
			 * input 	0-7: Camera
			 * liftB 	-4096-4096: -1.00-1.00
			 */
			void ATEMuni::setCameraControlLiftB(uint8_t input, int16_t liftB) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 8;
				_packetBuffer[12+_cBBO+4+4+2] = 0;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x04;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(getCameraControlLiftR(input));
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(getCameraControlLiftR(input));
				_packetBuffer[12+_cBBO+4+4+18] = highByte(getCameraControlLiftG(input));
				_packetBuffer[12+_cBBO+4+4+19] = lowByte(getCameraControlLiftG(input));

				_packetBuffer[12+_cBBO+4+4+20] = highByte(liftB);
				_packetBuffer[12+_cBBO+4+4+21] = lowByte(liftB);

				_packetBuffer[12+_cBBO+4+4+22] = highByte(getCameraControlLiftY(input));
				_packetBuffer[12+_cBBO+4+4+23] = lowByte(getCameraControlLiftY(input));

				_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Gamma B
			 * input 	0-7: Camera
			 * gammaB 	-4096-4096: -1.00-1.00
			 */
			void ATEMuni::setCameraControlGammaB(uint8_t input, int16_t gammaB) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 8;
				_packetBuffer[12+_cBBO+4+4+2] = 1;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x04;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(getCameraControlGammaR(input));
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(getCameraControlGammaR(input));
				_packetBuffer[12+_cBBO+4+4+18] = highByte(getCameraControlGammaG(input));
				_packetBuffer[12+_cBBO+4+4+19] = lowByte(getCameraControlGammaG(input));

				_packetBuffer[12+_cBBO+4+4+20] = highByte(gammaB);
				_packetBuffer[12+_cBBO+4+4+21] = lowByte(gammaB);

				_packetBuffer[12+_cBBO+4+4+22] = highByte(getCameraControlGammaY(input));
				_packetBuffer[12+_cBBO+4+4+23] = lowByte(getCameraControlGammaY(input));

				_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Gain B
			 * input 	0-7: Camera
			 * gainB 	-4096-4096: -1.00-1.00
			 */
			void ATEMuni::setCameraControlGainB(uint8_t input, int16_t gainB) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 8;
				_packetBuffer[12+_cBBO+4+4+2] = 2;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x04;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(getCameraControlGainR(input));
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(getCameraControlGainR(input));
				_packetBuffer[12+_cBBO+4+4+18] = highByte(getCameraControlGainG(input));
				_packetBuffer[12+_cBBO+4+4+19] = lowByte(getCameraControlGainG(input));

				_packetBuffer[12+_cBBO+4+4+20] = highByte(gainB);
				_packetBuffer[12+_cBBO+4+4+21] = lowByte(gainB);

				_packetBuffer[12+_cBBO+4+4+22] = highByte(getCameraControlGainY(input));
				_packetBuffer[12+_cBBO+4+4+23] = lowByte(getCameraControlGainY(input));

				_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Lift Y
			 * input 	0-7: Camera
			 * liftY 	-4096-4096: -1.00-1.00
			 */
			void ATEMuni::setCameraControlLiftY(uint8_t input, int16_t liftY) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 8;
				_packetBuffer[12+_cBBO+4+4+2] = 0;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x04;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(getCameraControlLiftR(input));
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(getCameraControlLiftR(input));
				_packetBuffer[12+_cBBO+4+4+18] = highByte(getCameraControlLiftG(input));
				_packetBuffer[12+_cBBO+4+4+19] = lowByte(getCameraControlLiftG(input));
				_packetBuffer[12+_cBBO+4+4+20] = highByte(getCameraControlLiftB(input));
				_packetBuffer[12+_cBBO+4+4+21] = lowByte(getCameraControlLiftB(input));

				_packetBuffer[12+_cBBO+4+4+22] = highByte(liftY);
				_packetBuffer[12+_cBBO+4+4+23] = lowByte(liftY);

				_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Gamma Y
			 * input 	0-7: Camera
			 * gammaY 	-4096-4096: -1.00-1.00
			 */
			void ATEMuni::setCameraControlGammaY(uint8_t input, int16_t gammaY) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 8;
				_packetBuffer[12+_cBBO+4+4+2] = 1;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x04;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(getCameraControlGammaR(input));
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(getCameraControlGammaR(input));
				_packetBuffer[12+_cBBO+4+4+18] = highByte(getCameraControlGammaG(input));
				_packetBuffer[12+_cBBO+4+4+19] = lowByte(getCameraControlGammaG(input));
				_packetBuffer[12+_cBBO+4+4+20] = highByte(getCameraControlGammaB(input));
				_packetBuffer[12+_cBBO+4+4+21] = lowByte(getCameraControlGammaB(input));

				_packetBuffer[12+_cBBO+4+4+22] = highByte(gammaY);
				_packetBuffer[12+_cBBO+4+4+23] = lowByte(gammaY);


				_finishCommandPacket();

			}

			/**
			 * Set Camera Control; Gain Y
			 * input 	0-7: Camera
			 * gainY 	-4096-4096: -1.00-1.00
			 */
			void ATEMuni::setCameraControlGainY(uint8_t input, int16_t gainY) {

		  		_prepareCommandPacket(PSTR("CCmd"),24);

					// Preset values:
				_packetBuffer[12+_cBBO+4+4+1] = 8;
				_packetBuffer[12+_cBBO+4+4+2] = 2;

				_packetBuffer[12+_cBBO+4+4+4] = 0x80;
				_packetBuffer[12+_cBBO+4+4+9] = 0x04;

				_packetBuffer[12+_cBBO+4+4+0] = input;

				_packetBuffer[12+_cBBO+4+4+16] = highByte(getCameraControlGainR(input));
				_packetBuffer[12+_cBBO+4+4+17] = lowByte(getCameraControlGainR(input));
				_packetBuffer[12+_cBBO+4+4+18] = highByte(getCameraControlGainG(input));
				_packetBuffer[12+_cBBO+4+4+19] = lowByte(getCameraControlGainG(input));
				_packetBuffer[12+_cBBO+4+4+20] = highByte(getCameraControlGainB(input));
				_packetBuffer[12+_cBBO+4+4+21] = lowByte(getCameraControlGainB(input));

				_packetBuffer[12+_cBBO+4+4+22] = highByte(gainY);
				_packetBuffer[12+_cBBO+4+4+23] = lowByte(gainY);


				_finishCommandPacket();

			}


			/**
			 * Get Tally By Source; Sources
			 */
			uint16_t ATEMuni::getTallyBySourceSources() {
				return atemTallyBySourceSources;
			}
			
			/**
			 * Get Tally By Source; Video Source
			 * sources 	0-46: Number of
			 */
			uint16_t ATEMuni::getTallyBySourceVideoSource(uint16_t sources) {
				return atemTallyBySourceVideoSource[sources];
			}
			
			/**
			 * Get Tally By Source; Tally Flags
			 * sources 	0-46: Number of
			 */
			uint8_t ATEMuni::getTallyBySourceTallyFlags(uint16_t sources) {
				return atemTallyBySourceTallyFlags[sources];
			}